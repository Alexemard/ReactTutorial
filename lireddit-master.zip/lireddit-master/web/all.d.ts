declare module "next-apollo";
